Icons by http://p.yusukekamiyamane.com/
Downloaded from http://www.iconarchive.com/show/fugue-icons-by-yusuke-kamiyamane.html

Edited to remove semi transparent pixels.
